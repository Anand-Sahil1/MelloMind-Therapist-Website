const express = require("express");
const router = express.Router();
const {MoodData} = require("../models");

router.get("/:moodDate", async (req, res) => {
  const selectedDate = req.params.moodDate;
  const MC = await MoodData.findOne({ where: { moodDate: selectedDate } });
  res.json(MC);
});

router.post("/", async (req, res) => {
    const MC = req.body;
    await MoodData.create(MC);
    res.json(MC);
  });

module.exports = router;