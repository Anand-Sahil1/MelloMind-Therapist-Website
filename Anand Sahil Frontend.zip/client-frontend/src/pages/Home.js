import React from 'react'


function Home() {
  return (
    <div id="HomeContainer">
    <nav>
      <ul className="navlist">
        <li className="selected"><a href="/">Home</a></li>
        <li><a href="">Find a Therapist</a></li>
        <li><a href="">Donate</a></li>
        <li><a href="">Your Conversations</a></li>
        <li><a href="/MC">Your Mood Tracker</a></li>
      </ul>
    </nav>
    </div>
  )
}

export default Home