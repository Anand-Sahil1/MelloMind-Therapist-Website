module.exports = (sequelize, DataTypes) => {

    const MoodData = sequelize.define("MoodData", {
        moodDate: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        mood: {
            type: DataTypes.STRING,
            allowNull: false,
        },
    });

    return MoodData;
};