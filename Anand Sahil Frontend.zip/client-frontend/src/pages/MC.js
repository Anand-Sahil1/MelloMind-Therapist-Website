import React, { useState } from "react";
import Calendar from "react-calendar";
import { Modal, Button } from 'react-bootstrap';
import './Calendar.css';
import axios from "axios";

function MC() {
  const [date, setDate] = useState(new Date());
  const today = new Date();
  const [showModal, setShowModal] = useState(false);
  const [selectedOption, setSelectedOption] = useState(null);
 
  const onChange = date => {
    setDate(date);
  };

  const onDayClick = async (value) => {
    const selectedDate = value.toLocaleDateString("en-GB", {day: '2-digit', month: '2-digit', year: 'numeric'}).split('/').join('-'); // convert the date to "dd-mm-yyyy" format
    const response = await axios.get(`http://localhost:3001/MC/${selectedDate}`);
    if ((value.getTime() === new Date().setHours(0, 0, 0, 0)) && (response.moodDate != selectedDate)) {
      // If the selected date does not exist in the database, show the modal
      setShowModal(true);
    } else {
      // If the selected date exists in the database, do not show the modal
      setShowModal(false);
    }
  };

  const handleOptionClick = (option) => {
    setSelectedOption(option);

    const data = {
      moodDate: date.toLocaleDateString("en-GB", {day: '2-digit', month: '2-digit', year: 'numeric'}).split('/').join('-'), 
      // convert the date to "dd-mm-yyyy" format
      mood: option
    };
    
    axios.post("http://localhost:3001/MC", data)
      .then((response) => {
        console.log("Data has been sent to the server:", data);
      })
      .catch((error) => {
        console.error("Error while sending data:", error);
      });
  };

  return (
    <div id="container">
    <nav>
      <ul className="navlist">
        <li><a href="/">Home</a></li>
        <li><a href="">Find a Therapist</a></li>
        <li><a href="">Donate</a></li>
        <li><a href="">Your Conversations</a></li>
        <li className="selected"><a href="">Your Mood Tracker</a></li>
      </ul>
    </nav>

    <br />

    <div id="mainSection">
      <p id="MCGuide">Click {today.toLocaleDateString("en-US", { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })} In The Calendar To Select Mood</p> 
      <div id="MCGuide">{selectedOption && <p>Mood: {selectedOption}</p>} </div>

      <Calendar onChange={onChange} value={date} onClickDay={onDayClick} />
    </div>

    <Modal show={showModal} onHide={() => setShowModal(false)}>

      <Modal.Header><br/>
        <Modal.Title id="ModalHeader">HOW ARE YOU FEELING TODAY?</Modal.Title>
      </Modal.Header> <br/>

      <Modal.Body id="ModalBody">
        <Button className="modal-btn" disabled={selectedOption !== null} onClick={() => handleOptionClick('Very Happy')}>Very Happy</Button>{' '}<br/><br/>
        <Button className="modal-btn" disabled={selectedOption !== null} onClick={() => handleOptionClick('Happy')}>Happy</Button>{' '}<br/><br/>
        <Button className="modal-btn" disabled={selectedOption !== null} onClick={() => handleOptionClick('Neutral')}>Neutral</Button>{' '}<br/><br/>
        <Button className="modal-btn" disabled={selectedOption !== null} onClick={() => handleOptionClick('Sad')}>Sad</Button>{' '}<br/><br/>
        <Button className="modal-btn" disabled={selectedOption !== null} onClick={() => handleOptionClick('Very Sad')}>Very Sad</Button>
      </Modal.Body>

      <br/><br/>

      <Modal.Footer>
        <Button className="modal-btn1" onClick={() => setShowModal(false)}>Close</Button>
      </Modal.Footer>

    </Modal>
  </div>
  )
}

export default MC  



