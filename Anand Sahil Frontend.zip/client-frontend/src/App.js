import './App.css';
import {BrowserRouter as Router, Route, Routes, Switch} from "react-router-dom";
import MC from "./pages/MC";
import Home from './pages/Home';

function App() {
  return (
    <div className="App">
       <Router> 
        <Routes>
        <Route path="/" exact Component={Home}/>
        <Route path="/MC" exact Component={MC}/>
        </Routes>
      </Router> 
    </div> );}

export default App;
